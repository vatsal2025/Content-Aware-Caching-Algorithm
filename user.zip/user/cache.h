#ifndef CACHE_H
#define CACHE_H

#include "kernel/types.h"
#include <stdint.h>

#define CACHE_SIZE (6 * 1024 * 1024)  // 6 MB cache
#define NUM_TEST_FILES 100
#define NUM_ACCESSES 20000
#define NUM_BURST_ACCESSES 10000

// Cache entry structure
struct cache_entry {
    char filename[DIRSIZ];
    uint8_t *data;
    int size;
    int last_used;
    int importance;  // For content-aware caching
    struct cache_entry *next;
};

// Cache structure
struct cache {
    struct cache_entry *entries;
    int max_size;
    int current_size;
    int num_entries;
    int clock;  // For LRU
};

// Function prototypes
void init_cache(struct cache *c, int max_size);
void free_cache(struct cache *c);
int lru_cache_lookup(struct cache *c, const char *filename, uint8_t **data, int *size);
int content_aware_cache_lookup(struct cache *c, const char *filename, uint8_t **data, int *size);
void create_test_files(void);
void generate_workload(int num_accesses);
void generate_burst_workload(int num_accesses);
void run_test(const char *name, int (*cache_lookup)(struct cache*, const char*, uint8_t**, int*));

#endif // CACHE_H 