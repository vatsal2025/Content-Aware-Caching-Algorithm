#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"
#include "kernel/fs.h"
#include "kernel/fcntl.h"
#include <stdint.h>
#include "cache.h"

int main(int argc, char *argv[]) {
    printf("Content-Aware Caching Algorithm Test\n");
    
    // Create test files
    printf("Created %d test files.\n", NUM_TEST_FILES);
    create_test_files();
    
    // Generate and test with realistic workload
    printf("Generated realistic workload of %d file accesses.\n", NUM_ACCESSES);
    printf("Using cache size of %d MB\n", CACHE_SIZE / (1024 * 1024));
    printf("(Approximately 25%% of total data size)\n");
    
    // Test LRU caching
    printf("Testing standard LRU caching...\n");
    run_test("LRU", lru_cache_lookup);
    
    // Test content-aware caching
    printf("Testing content-aware caching...\n");
    run_test("Content-Aware", content_aware_cache_lookup);
    
    // Test with burst pattern
    printf("--- Additional Test: Important Files Burst Pattern ---\n");
    printf("Generated important-files burst workload of %d file accesses.\n", NUM_BURST_ACCESSES);
    
    // Test LRU with burst pattern
    printf("Testing standard LRU caching...\n");
    run_test("LRU", lru_cache_lookup);
    
    // Test content-aware with burst pattern
    printf("Testing content-aware caching...\n");
    run_test("Content-Aware", content_aware_cache_lookup);
    
    exit(0);
} 